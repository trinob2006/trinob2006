# Methodology for Android forensic

For different technical reasons, it is more complex to do a forensic analysis of an Android phone.

Currently MVT allows to perform two different checks on an Android phone:

* Download APKs installed in order to analyze them
* Extract Android backup in order to look for suspicious SMS
